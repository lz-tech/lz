package jp.co.fsi.nexticj.supporttool.autodeploy;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.tools.ant.BuildLogger;
import org.apache.tools.ant.DefaultLogger;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.ProjectHelper;

public class ExecuteDeploy {
	public void Deploy(List<String> targetList, Map<String, LoginInfo> orgMap, String workFolder, String resultFile) {
		// 実行結果
		Map<String, Boolean> mapResult = new HashMap<String, Boolean>();
		Map<Long,Integer> map = new HashMap<Long,Integer>();
		System.out.println("availableProcessors:" + Runtime.getRuntime().availableProcessors());
		// スレッド数取得
		Propertiy p = Propertiy.getInstance();
		int pcount = Integer.parseInt(p.getThreadmax());

        for(int i=0;i<pcount;i++){
           Thread t = new MyThread1(targetList, map, workFolder, mapResult, orgMap, pcount);
            map.put(t.getId(),Integer.valueOf(i));
            t.start();
        }

        // 結果出力
        resultOutput(targetList, orgMap, mapResult, workFolder + resultFile);
	}

	/**
     * デプロイ結果を書き込む
     * @param deployResult
     * @param
     */
    public void resultOutput(List<String> targetList, Map<String, LoginInfo> orgMap, Map<String, Boolean> mapResult, String fileName) {
        // ファイル作成result.csv
        File result = new File(fileName);

        // ファイル存在
        if (!result.exists()) {
            try {
                result.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        FileOutputStream out = null;
        OutputStreamWriter osw = null;
        BufferedWriter bw = null;

        try {
            out = new FileOutputStream(result);
            osw = new OutputStreamWriter(out, "UTF-8");
            bw = new BufferedWriter(osw);

            for (String orgName : targetList) {
                bw.append(orgName + "," + orgMap.get(orgName).getVersion() + "," + mapResult.get(orgName) + ",true");
                bw.append("\r\n");
            }
        } catch (Exception e) {
        } finally {
            if (bw != null) {
                try {
                    bw.close();
                    bw = null;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if (osw != null) {
                try {
                    osw.close();
                    osw = null;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if (out != null) {
                try {
                    out.close();
                    out = null;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

/**
 * スレッド用クラス
 * @author
 *
 */
 class MyThread1 extends Thread {

    private List<String> list;
    private Map<Long,Integer> map;
    private String workFolder;
    private Map<String, Boolean> mapResult;
    private Map<String, LoginInfo> loginMap;
    private int pcount;

    public MyThread1(List<String> list, Map<Long,Integer> map, String workFolder, Map<String, Boolean> mapResult, Map<String, LoginInfo> loginMap, int pcount){
        this.list = list;
        this.map = map;
        this.workFolder = workFolder;
        this.mapResult = mapResult;
        this.loginMap = loginMap;
        this.pcount = pcount;
    }

    @Override
    public void run() {

        int i = map.get(Thread.currentThread().getId());

        for(;i<list.size();i+=pcount){
 
        	this.mapResult.put(list.get(i), ExecuteDeploy(workFolder, list.get(i), loginMap));
        }
    }

    /**
     * デプロイ実行
     * @param orgName
     */
	public Boolean ExecuteDeploy(String workFolder, String orgName, Map<String, LoginInfo> loginMap) {
		try {
			Project project = new Project();
			project.init();
			// buildファイル
			File buildFile = getBuildFild(workFolder, orgName + "_" + loginMap.get(orgName).getVersion());
			ProjectHelper.getProjectHelper().parse(project, buildFile);

			//loggerの設定
			BuildLogger buildlogger = getBuildLogger();
			project.addBuildListener(buildlogger);

			// ログイン情報取得
			LoginInfo loginInfo = loginMap.get(orgName);

			// ユーザ名パスワード設定
			project.setNewProperty("sf.username", loginInfo.getUserId());
			project.setNewProperty("sf.password", loginInfo.getPassWord());

			Propertiy p = Propertiy.getInstance();
			String proxyHost = p.getProxyHost();
			String proxyPort = p.getProxyPort();
			if (!proxyHost.isEmpty() && !proxyPort.isEmpty()) {
				project.setNewProperty("proxy.host", proxyHost);
				project.setNewProperty("proxy.port", proxyPort);
			}

			project.executeTarget(project.getDefaultTarget());
			return true;
		} catch (Exception ex) {
			return false;
		}
	}
	private BuildLogger getBuildLogger() {
		BuildLogger buildlogger = new DefaultLogger();
		buildlogger.setMessageOutputLevel(Project.MSG_INFO);
		buildlogger.setOutputPrintStream(new PrintStream(System.out));
		buildlogger.setErrorPrintStream(new PrintStream(System.err));
		buildlogger.setEmacsMode(false);
		return buildlogger;
	}
	private File getBuildFild(String workFolder, String orgName) {
		return new File(workFolder + orgName + "/build.xml");
	}
}