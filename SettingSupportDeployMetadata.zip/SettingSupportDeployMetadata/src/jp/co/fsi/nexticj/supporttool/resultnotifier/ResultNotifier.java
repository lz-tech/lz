package jp.co.fsi.nexticj.supporttool.resultnotifier;
import java.util.List;
import java.util.Map;

import jp.co.fsi.nexticj.supporttool.sfdc.bean.SettingSupportResultBean;
import jp.co.fsi.nexticj.supporttool.sfdc.bean.SettingSupportResultBean.SettingStatus;
import jp.co.fsi.nexticj.supporttool.sfdc.webservice.SetSettingSupportResult;

/**
 * 配信後設定の結果通知クラス
 * @author keinakamu
 *
 */
public class ResultNotifier {

	/** 作業ディレクトリ */
	private final String CURRENT_DIR;

	/* 設定ファイル名 */
	private final static String CONF_FILENAME = "monitoring.conf";

	/* 設定ファイルの定数 */
	private final static String PROPERTY_PROXYHOST = "proxy_host";
	private final static String PROPERTY_PROXYPORT = "proxy_port";
	private final static String PROPERTY_LOGININFO = "logininfo";

	/* リトライ設定 */
	private final static int RETRY_MAX_COUNT = 2;  // 0=リトライしない
	private final static int RETRY_WATI_SEC = 5;     // 次のリトライまで待つ秒数

	/**
	 * コンストラクタ
	 */
	public ResultNotifier() {
		CURRENT_DIR = System.getProperty("user.dir");
	}

	public boolean start() {

		return true;
	}







	/**
	 * WebServiceに設定結果を送信する
	 * @return
	 */
	public boolean setMetaDeployResult(List<String> targetList, Map<String, Boolean> mapResult) {

		SetSettingSupportResult sssr = new SetSettingSupportResult();

		for(String orgName : targetList) {
			SettingSupportResultBean b = new SettingSupportResultBean();
			b.setOrgName(orgName);
			b.setMetadata(mapResult.get(orgName) ? SettingStatus.SUCCESS : SettingStatus.ERROR);
			sssr.upsertSendData(b);
		}

		// 実行,リトライ処理あり
		int retryCount = 2;  // リトライ回数
		int wait = 5;        // 次のリトライまでの待ち秒数
		try {
			while(true) {
				boolean result = sssr.execute();
				if (!result && retryCount > 0) {
					System.out.println("[INFO] "+ wait +"秒後にリトライします。");
					Thread.sleep(wait * 1000);
					retryCount--;
				} else {
					break;
				}
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		return true;
	}
}
