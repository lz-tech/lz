package jp.co.fsi.nexticj.supporttool.util.file;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Byte型のファイル読み込み・書き込み
 * @author keinakamu
 *
 */
public class FileIoBytes {

	private final Path path;

	/**
	 * @return path
	 */
	public Path getPath() {
		return path;
	}

	/**
	 * コンストラクタ
	 * @param filePath ファイルパス
	 */
	public FileIoBytes(String filePath) {
		this.path = new File(filePath).toPath();
	}

	/**
	 * 書き込み
	 * @param inputData データ
	 * @throws IOException
	 */
	public void writeAll(byte[] inputData) throws IOException {
		Files.write(path, inputData);
	}

	/**
	 * 読み込み
	 * @return データ
	 * @throws IOException
	 */
	public byte[] readAll() throws IOException {
		return Files.readAllBytes(path);
	}
}
