package jp.co.fsi.nexticj.supporttool.autodeploy;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Path;

import jp.co.fsi.nexticj.supporttool.util.file.ApplicationPath;
import jp.co.fsi.nexticj.supporttool.util.file.PropertyReader;

/**
 * deploymeta.confの設定を格納
 * @author keinakamu
 *
 */
class Propertiy {

	// 設定ファイル名
	private final static String CONF_FILENAME = "deploymeta.conf";

	// 定数
	private final static String PROPERTY_PROXYHOST = "proxy_host";
	private final static String PROPERTY_PROXYPORT = "proxy_port";
	private final static String PROPERTY_LOGININFO = "logininfo";
	private final static String PROPERTY_THREADMAX = "thread_max";

	// エラー判定
	private boolean isReadError;

	// プロパティ設定
	private String proxyHost;
	private String proxyPort;
	private String loginInfo;
	private String threadmax;

	/**
	 * @return isReadError
	 */
	public boolean isReadError() {
		return isReadError;
	}

	/**
	 * @return proxyHost
	 */
	public String getProxyHost() {
		return proxyHost;
	}

	public String getThreadmax() {
		return threadmax;
	}

	/**
	 * @return proxyPort
	 */
	public String getProxyPort() {
		return proxyPort;
	}

	/**
	 * @return loginInfo
	 */
	public String getLoginInfo() {
		return loginInfo;
	}

	/**
	 * コンストラクタ
	 * @throws URISyntaxException
	 * @throws IOException
	 */
	private Propertiy() {
		try {
			Path appPath = ApplicationPath.getParentPath(Propertiy.class);
			String path = new File(appPath.toString(),CONF_FILENAME).getCanonicalPath();
			PropertyReader reader = new PropertyReader(path);
			if(reader.isExistsFile()) {
				this.proxyHost = reader.getProperty(PROPERTY_PROXYHOST, "");
				this.proxyPort = reader.getProperty(PROPERTY_PROXYPORT, "");
				this.loginInfo = reader.getProperty(PROPERTY_LOGININFO);
			    this.threadmax = reader.getProperty(PROPERTY_THREADMAX);
				this.isReadError = false;
			} else {
				this.isReadError = true;
				System.out.println("[ERROR] プロパティファイルが読み込めません。: " + path );
			}
		} catch (URISyntaxException | IOException e) {
			this.isReadError = true;
			e.printStackTrace();
			System.out.println("[ERROR] プロパティファイルの読み込みでエラーが発生しました。");
		}
	}

	/**
	 * インスタンスを返す
	 * @return インスタンス
	 */
	public static Propertiy getInstance() {
		return ConfigInstanceHolder.INSTANCE;
	}

	/**
	 * インスタンスを保持する内部クラス
	 * @author keinakamu
	 *
	 */
    public static class ConfigInstanceHolder {
        /** 唯一のインスタンス */
        private static final Propertiy INSTANCE = new Propertiy();
    }
}
