package jp.co.fsi.nexticj.supporttool.sfdc.login;

import com.sforce.soap.SettingSupportInfoWebService.Connector;
import com.sforce.soap.SettingSupportInfoWebService.SoapConnection;
import com.sforce.soap.partner.PartnerConnection;
import com.sforce.ws.ConnectionException;
import com.sforce.ws.ConnectorConfig;

/**
 * Salesforce組織にアクセスする処理(Partner WSDL用)
 *
 * @author keinakamu
 *
 */
public class LoginUtilPartner extends AbstractLoginUtil {

	private PartnerConnection connection;
	private SoapConnection sconnection;
	final static String API_ENDPOINT = "u/";

	/**
	 * コンストラクタ
	 */
	public LoginUtilPartner() {
		super();
		this.connection = null;
		this.sconnection = null;
	}

	/**
	 * 接続情報
	 *
	 * @return PartnerConnection
	 */
	public PartnerConnection getConnection() {
		return connection;
	}

	/**
	 * SOAP接続情報
	 *
	 * @return SoapConnection
	 */
	public SoapConnection getSoapConnection() {
		return sconnection;
	}

	/**
	 * ログイン処理
	 *
	 * @return ログイン 成功(true)/失敗(false)
	 */
	public boolean login() {
		ConnectorConfig config = new ConnectorConfig();
		config.setUsername(getUsername());
		config.setPassword(getPassword());

		if (isUseProxy()) {
			config.setProxy(getProxyHost(), getProxyPort());
		}


		String authEndpoint = (isSandbox()? LOGIN_SANDBOX : LOGIN_DEFAULT)
				+ API_ENDPOINT
				+ getApiVersion();
		config.setAuthEndpoint(authEndpoint);
	    config.setTraceMessage(false);  // メッセージを詳細出力する場合、trueに変更する

		// ログイン処理
		try {
			connection = com.sforce.soap.partner.Connector.newConnection(config);

// 			//デバッグ用
//			System.out.println("Auth EndPoint: " + config.getAuthEndpoint());
//			System.out.println("Service EndPoint: " + config.getServiceEndpoint());
//			System.out.println("Username: " + config.getUsername());
//			System.out.println("SessionId: " + config.getSessionId());

			// 追加
			ConnectorConfig sconfig = new ConnectorConfig();
			sconfig.setAuthEndpoint(authEndpoint);
			sconfig.setSessionId(config.getSessionId());
	        sconnection = Connector.newConnection(sconfig);

			return true;

		} catch (ConnectionException e) {
//			e.printStackTrace();
			return false;
		}
	}
}
