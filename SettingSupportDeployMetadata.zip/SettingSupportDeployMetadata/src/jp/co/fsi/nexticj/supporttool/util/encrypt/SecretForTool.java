package jp.co.fsi.nexticj.supporttool.util.encrypt;

import java.util.Base64;

/**
 * secret_forTool.txt の値の生成・復元クラス
 * @author keinakamu
 *
 */
public class SecretForTool {

	private SecretForTool() {}

	/**
	 * 復元する
	 */
	public static String decrypt(final String secret) {
		return new StringBuffer(new String(Base64.getDecoder().decode(new StringBuffer(secret).reverse().toString()))).reverse().toString();
	}

	/**
	 * 複雑にする
	 */
	public static String encrypt(final String plain) {
		return new StringBuffer(Base64.getEncoder().encodeToString(new StringBuffer(plain).reverse().toString().getBytes())).reverse().toString();
	}
}
